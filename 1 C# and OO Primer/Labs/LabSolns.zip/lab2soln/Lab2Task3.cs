using System;

class Numbers
{
   public static void Main()
   {
        float num1 = 9;
        float num2 = 6;

        Console.WriteLine("Their sum is: " + (num1 + num2));
        Console.WriteLine("Their difference is: " + (num1 - num2));
        Console.WriteLine("Their product is: " + (num1 * num2));
   }
}