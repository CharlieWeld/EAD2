// for loop
// a program which displays a countdown from 5 to 0 (inclusive)

using System;						

namespace Iteration                     
{
    class CountDown          
    {
        private static void Main()          
        {
            for (int i=5; i >= 0; i--)              // loop i from 5 downto 0
            {
                Console.WriteLine(i);
            }
        }
    }
} 
	


